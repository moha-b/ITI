void main(){
  print(3/2);
  print(3~/2);
  int x = 3;
  print(x.isEven?"Even Number":"Odd Number");
}
/*
Operators
---------
1- Arithmetic
+ - * / ~/ %
++ --
2- Comparison
> > = < <= == !=
3- Logical Op
&& || !
4-Bitwise
& | ^
<< >>
5- conditional
  ? :
6- ?? , ??=
7- is - as
8- .. cascade
 */