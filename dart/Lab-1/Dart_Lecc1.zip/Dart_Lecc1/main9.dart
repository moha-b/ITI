void main(){
  for(int  i =0 ; i<101 ; i++){
    if(i.isEven)continue;
    print(i);
  }
}