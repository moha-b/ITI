import 'dart:io';
void main(){
  print("Hello dart");
  print("Hello Flutter");
  stdout.write("Hello Dart");
  stdout.write("Hello Flutter");
}