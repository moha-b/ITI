void main(){
  int i = 5;
  if(i.isOdd){
    print('Odd Number');
  }else {
    print('Even Number');
  }

  int a = 8;
  switch(a){
    case 3:
      print('a = 3');
    case 5:
    case 8:
      print('a = 5');
    case 9:
      print('a = 9');
  }

  String s ='';
  for(int i =0; i<5 ; i++){
    s+='*';
  }

  int j = 0;
  while(j++<5){
    print(j);

  }


}

/*
Control Statements
1- Conditional Statement
2- Looping
 */