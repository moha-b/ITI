import 'str_ext.dart';

void main(){
  String name = 'mArWA';
  print(name.capitalize());
}

