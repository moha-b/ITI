void main(){
  setData(id:1, name: 'omar', salary:2000, phone: '12358885');
}
void setData({required String name, required String phone, double salary=0.0, int? id}){

}