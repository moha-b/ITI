void main(){
  var name;
 name ??= 'Guest';
  print('Hello $name');
}