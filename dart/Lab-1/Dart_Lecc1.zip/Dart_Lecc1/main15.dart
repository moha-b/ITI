void main(){
  Function fn =  (String name)=>  print('Hi $name');
  fn('marwa');

  print(fn.runtimeType);


}


