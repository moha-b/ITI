void main(){
  String? name;
  name = 'marwa';
  // print(name!.toUpperCase());
  String upperName = name!.toUpperCase();
}
/*
non-nullable     nullable
String            String?
 */