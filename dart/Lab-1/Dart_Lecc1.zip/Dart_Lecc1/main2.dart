void main(){
  num x = 5.1;
  num y = 2.1;
  int z = 9;
  double m = 2.5;
  String name = 'Flutter';
  String name1 = "Flutter"
      ""
      "dart";
  String name2 = '''Flutter 
  
  Dart''';

  print(name1);
  print(name2);

  print(x.runtimeType);
  var w = 7;
  w = 8;
  print(w.runtimeType);
  int g =1;
}

/*
Data types
---------
1-num
  int
  double
2- String
3-List
4-Set
5-Map
6-Symbol
7-Runes
8-Null
 */