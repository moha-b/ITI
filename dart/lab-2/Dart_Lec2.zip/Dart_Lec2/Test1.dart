class Test1{
  int x=0;
  int _y =0;
  // Test1(int x){
  //   this.x =x;
  // }
  Test1(this.x);
  Test1._instance();
  Test1.marwa();
  void _incrementByTwo(){
    print(x+=2);
  }
}



void main(){
  Test1 t = Test1(5);
  t._incrementByTwo();
}