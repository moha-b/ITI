class Fruit {
  void setName() {
    print('Fruit');
  }
}

class Banana extends Fruit {
  @override
  void setName() {
    print('Banana');
  }

  void getColor() {
    print('Yellow');
  }
}

class Apple extends Fruit {
  @override
  void setName() {
    print('Apple');
  }

  void getSeason() {
    print('Summer');
  }
}

void main(){
  Fruit f = Banana();
  f.setName();
  if(f is Banana) {
    f.getColor();
  }

  if(f is Apple) {
    f.getSeason();
  }
  getFruit(Apple());
}

void getFruit(Fruit f){

}