mixin A{
  void printA(){
    print('A');
  }

  void test(){
    print('Test A');
  }
}
mixin B{
 void printB(){
   print('B');
  }
  void test(){
    print('Test B');
  }
}

class Mix with B,A{
  @override
  void printA() {
    print('A and B');
  }
}

void main(){
  Mix m = Mix();
  m.printA();
  m.printB();
  m.test();
}