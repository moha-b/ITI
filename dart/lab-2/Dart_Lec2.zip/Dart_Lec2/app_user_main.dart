import 'AppUser.dart';

void main(){
  AppUser appUser = AppUser();
  appUser.username ='marwa';
  print(appUser.hashCode);

  AppUser appUser1 = AppUser();
  print(appUser1.username);
  print(appUser1.hashCode);
}