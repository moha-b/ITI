class User {
  String username = '';
  String password = '';

  User._instance();

  static final  User user = User._instance();
}
