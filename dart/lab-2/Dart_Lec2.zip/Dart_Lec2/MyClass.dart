class MyClass{
  void info(){
    print('Testing class');
  }
}
abstract class NewClass{
  int calc(int x, int y);
}
class MyClassImpl implements MyClass, NewClass{
  @override
  void info() {
    print('Info');
  }

  @override
  int calc(int x, int y) {
   return x*y;
  }

}
