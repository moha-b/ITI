class Test3 {
  int x = 3;
}

class SubTest extends Test3 {
  int x = 7;
  void printX(){
    print(x);//7
    print(super.x);//3
  }
}

void main() {
  SubTest t1 = SubTest();
  t1.printX();
}
