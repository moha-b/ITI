class Test{
  int x=0;

  void incrementByTwo(){
    print(x+=2);
  }

}