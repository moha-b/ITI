import 'User.dart';

void main(){
  // User user = User();
  // print(user.hashCode);
  // user.username = 'marwa';
  //
  // User user1 = User();
  // print(user1.hashCode);
  // print(user1.username);
  User.user.username = 'marwa';
  print(User.user.username);
}