import 'Test1.dart';

class Demo{
  void add(){
    Test1 t = Test1(5);

  }
}