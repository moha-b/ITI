class Test4{
  Test4._(String name){
    print('Super Test');
  }
}

class SubTest4 extends Test4{
  SubTest4():super._('m');

}


void main(){
  SubTest4();

}

