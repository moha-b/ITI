abstract class Testing{
  void info(){
    print('Testing class');
  }
  int calc(int x, int y);
}

class SubTesting extends Testing{
  @override
  int calc(int x, int y) {
   return x+y;
  }
}

void main(){
  Testing t = SubTesting();
}