import 'test.dart';

void main() {
  var t;
  t = Test();
  t.x = 5;
  t.incrementByTwo();
  // Test()..x=5..incrementByTwo();

  Test t1 = Test();
  t1.incrementByTwo();

  var t2 = t;
  t2.x = 9;
  t.incrementByTwo();
  t = null;
  t2 = null;

}
