class Test2 {
  int x = 0;
  static int y = 0;

  Test2() {
    x++;
    y++;
  }
}

void main() {
  Test2 t = Test2();
  print(t.x);
  print(Test2.y);
  Test2 t1 = Test2();
  print(t1.x);
  print(Test2.y);


}
