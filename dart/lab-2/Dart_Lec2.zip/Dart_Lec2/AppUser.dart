class AppUser{
  String username ='';
  String password ='';

  AppUser._instance();
  static AppUser? _appUser;
  factory AppUser(){
    if(_appUser==null){
      _appUser = AppUser._instance();
    }
    return _appUser!;
  }
}