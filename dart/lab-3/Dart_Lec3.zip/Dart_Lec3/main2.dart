/*
                   Iterable (1,2,3)
     List[1,2,3]                         Set {1,2,3}
 1- index                           1- no index
 2- ordered                         2- ordered (linkedSet)
 3- duplication                     3- no duplication
 4- fixed length - growable
 -------------------------------------------------------
                      Map
                      1- key/value
                      2- key -> unique
                      3- value -> duplication

 */