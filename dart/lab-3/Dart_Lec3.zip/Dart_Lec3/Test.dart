class Test{
  String _name='';

  void setName(String name)=>_name = name;
  String getName()=> _name;

  String get name => _name;

  set name(String value) {
    _name = value;
  }

// set name(String name)=>_name=name;
  // String get name => _name;



}