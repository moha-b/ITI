import 'Test.dart';

void main(){
  Test t = Test();
  t.setName('Marwa');
  print(t.getName());
  
  t.name = 'Flutter';
  print(t.name);
}