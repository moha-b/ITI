import { View, Text } from 'react-native'
import React from 'react'

const CompletedTodos = () => {
  return (
    <View>
      <Text>CompletedTodos</Text>
    </View>
  )
}

export default CompletedTodos