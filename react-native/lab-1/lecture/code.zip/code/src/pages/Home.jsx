import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
} from "react-native";
import React, { useState } from "react";
import Todos from "../components/Todos";

const Home = ({}) => {
  const [todos, setTodos] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  const addTodo = () => {
    if (title) {
      const singleTodo = {
        id: Date.now(),
        done: false,
        title,
        description,
      };
      const allTodos = [...todos, singleTodo];
      setTodos(allTodos);
    }
  };

  return (
    <View
      style={{
        flex: 1,
        alignItems: "center",
        justifyContent: "flex-start",
        paddingTop: 50,
      }}
    >
      <Text style={styles.title}>Todo App</Text>
      <TextInput
        onChangeText={(value) => setTitle(value)}
        style={styles.input}
        placeholder="Enter Your Todo"
      />
      <TextInput
        onChangeText={(value) => setDescription(value)}
        style={styles.input}
        placeholder="Description"
      />
      <TouchableOpacity style={styles.button} onPress={addTodo}>
        <Text style={{ color: "#fff", fontSize: 20 }}>Save</Text>
      </TouchableOpacity>
      {todos.length !== 0 && (
        <>
          <View style={styles.divider} />
          <Todos todos={todos} />
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  title: {
    fontWeight: "500",
    fontSize: 25,
    marginBottom: 15,
  },
  input: {
    borderWidth: 1,
    borderColor: "gray",
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 15,
    marginBottom: 15,
    width: 300,
  },
  button: {
    padding: 5,
    backgroundColor: "black",
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
    height: 40,
    paddingHorizontal: 40,
  },
  divider: {
    width: "95%",
    height: 1,
    backgroundColor: "gray",
    marginVertical: 20,
  },
});
export default Home;
