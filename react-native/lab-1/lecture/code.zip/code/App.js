import Router from "./src/Router";
// import 'react-native-gesture-handler';

export default function App() {
  return (
    <Router />
  );
}
